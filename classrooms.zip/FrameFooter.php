<table width="760" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->

  <tr> 
   
      <td height="42" valign="top" class="text"><p>&nbsp;</p>
        <p><em><a href="admin.php">Copyright</a> <span class="style1">OCTET-Oberlin College 
        (C) 2012</span></em></p></td>

  </tr>
</table>
</body>
</html>
