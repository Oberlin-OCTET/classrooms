#!/usr/local/bin/php
<?php
global $url_images, $url_php;
$url_images = "http://www.oberlin.edu/OCTET/SmartClassroom/images/pictures/";
$url_css = "http://www.oberlin.edu/OCTET/CSS/classrooms/";
$url_php = "http://www.oberlin.edu/cgi-bin/cgiwrap/OCTET/classrooms/";
$file_path = "http://www.oberlin.edu/OCTET/files/classrooms/banner.txt";
?>