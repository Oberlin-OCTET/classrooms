<?php

$hostname = "localhost"; 
$username = "classroom";
$password = "EdTechClassrooms";
$db = "classrooms";

$prj_db = mysql_connect($hostname, $username, $password);

if(!$prj_db) die("<br><br><br><font color=\"red\"><b> !!! WARNING !!! The connection to the database server was severed. Please contact Albert Borroni at x8345. Site down!</b></font>");
mysql_select_db($db, $prj_db);


function closeit() {
	mysql_close();
}
?>

