#!/usr/local/bin/php
<style type="text/css">
<!--
.style2 {font-size: smaller}
-->
</style>
<table width="760" border="0" cellpadding="5" cellspacing="0" bordercolor="#990000">
  <!--DWLayoutTable-->
  <tr class="wrap"> 
      <td height="1"></td>
      <td></td>
      <td></td>
      <td></td>
      <td width="126"></td>
      <td width="59"></td>
      <td></td>
  </tr>
  <tr> 
  	<td width="10" rowspan="6" valign="top" class="wrap"><!--DWLayoutEmptyCell-->&nbsp;</td>
	<td colspan="5" align="center" valign="top" class="wrap">
	<strong><font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif">
	    Looking for what rooms someone is scheduled to teach in? </font></strong>
	</td>	
	<td width="10" rowspan="6" valign="top" class="wrap"><!--DWLayoutEmptyCell-->&nbsp;</td> 
  
</tr>	
<tr>
	<!-- Searches for information about a particular faculty member's schedule.
	$first and $last refers to the first and last part of the search string not first name and last name. This is 
	necessary because the instructor field contains names in a last name first name format e.g. Albert Borroni is 
	stored as Borroni Albert. The search string created searches for %borroni%alb% -->

	<td colspan="5" align="left" valign="top" >
		 <form name="form1" method="GET" action="Index.php">
                      <p>&nbsp;&nbsp;<strong>Last:&nbsp;&nbsp;
                      <input name="first" type="text" id="first">
                      </strong> <strong>First:&nbsp;&nbsp;
                      <input name="last" type="text" id="last">
                      </strong> 
                        <input name="Submit" type="submit" class="buttons" value="Display your schedule">
                        <br>
                        <em>only use your first name if you have the same last name as another instructor </em>
           </p>
					<input name="Step" type="hidden" id="Step" value="6">
		 </form>
	</td>
</tr>
<tr>	
   <!-- Searches for information based on the equipment that is in a particular room -->
	<td height="19" colspan="5" align="center" valign="top" nowrap class="wrap"> 
      <strong><font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif"> 
      Looking for a room with particular equipment in it? Search Classroom by selecting your criteria</font></strong></td>
  </tr>
  <form name="search" action="Index.php">
    <tr> 
   
      <td height="51" colspan="5" valign="top" class="results"><p><strong> <br>
          &nbsp;&nbsp; 
		  
		  <input type="hidden" value="1" name="Step" id="Step">
          <select name="building" id="building">
            <option value="dummy" selected>---Select Building---</option>
            <option value="Allen">Allen Art Building</option>
            <option value="Bibbins">Bibbins</option>
            <option value="AJLC">AJLC - Environmental Studies Building</option>
            <option value="King">King</option>
            <option value="Mudd">Mudd</option>
            <option value="Peters">Peters</option>
            <option value="Sev">Severance</option>
            <option value="SCenter">Science Center</option>
          </select>
		  <input type="hidden" value="1" name"search">
          <input name="room" type="text" id="room" onFocus="MM_setTextOfTextfield('room','','')" value="Room #" size="8">
          <input name="cap" type="text" id="cap" onFocus="MM_setTextOfTextfield('cap','','')" value="Capacity" size="8">
          &nbsp;Containing the following equipment:<br>
          </strong><strong><br>
          </strong></p></td>
     
    </tr>
    <tr> 
      <td width="185" height="78" valign="top" class="results"><p><strong> 
          </strong><strong>
<input type="checkbox" name="e1" value="Laserdisc">
</strong>Laserdisc<strong>
<br>
<input type="checkbox" name="e2" value="DVD">
          </strong>DVD Player<br>
          <strong> 
          <input type="checkbox" name="e3" value="Multistandard DVD">
          </strong>Code Free DVD Player <br>
          <strong>
          <input type="checkbox" name="e4" value="Multistandard VCR">
          </strong>Multistandard VCR<br>
          <strong>
          <input type="checkbox" name="e5" value="iPod Connection">
          </strong>iPod connection <strong>
          <br>
          <input type="checkbox" name="e16" value="Surround Sound">
          </strong>Surround Sound </p></td>
      <td width="185" valign="top" class="results"> <p><strong> 
          <input type="checkbox" name="e6" value="Data Projector">
</strong>Data Projector <br>
<strong>
<input type="checkbox" name="e7" value="Document Camera">
          </strong>Document Camera<br> 
          <strong> 
          <input type="checkbox" name="e8" value="16mm Film Projector">
          </strong>16mm Film Projector<br> 
          <strong> 
          <input type="checkbox" name="e9" value="Lantern Slide Projector">
          </strong>Lantern Slide Projectors<br> 
          <strong> 
          <input type="checkbox" name="e10" value="Articulated Arm">
          </strong>Articulated Arm Camera<br> 
          <strong> 
          <input type="checkbox" name="e11" value="Portable">
          </strong>Portable Doc. Camera</p>
        </td>
      <td width="185" valign="top" class="results"> 
          <strong>
		  <input type="checkbox" name="e18" value="VHS">
          </strong>VHS Player <br>
          <input type="checkbox" name="e12" value="Slide Projector">
          </strong>Slide Projector<br>
          <strong> 
          <input type="checkbox" name="e13" value="Screen">
          </strong>Screen<br>
          <strong> 
          <input type="checkbox" name="e14" value="Printer">
          </strong>Printer<br>
        <strong> 
          <input type="checkbox" name="e15" value="Scanner">
        </strong>Scanner
          <br>
          <strong>
          <input type="checkbox" name="e19" value="BluRay">
          </strong>BluRay Player<br>
      </strong></p></td>
      <td colspan="2" valign="top" class="results"><strong> 
        </strong>        <strong> 
        <input type="checkbox" name="e17" value="Computer Lab">
        </strong>Computer Lab<br>
        <br>
        List of <a href="http://spreadsheets.google.com/a/oberlin.edu/ccc?key=0AtS2pmir63NwdE93RW5HS25uczA2T3A4Y2F1bGFTOHc&hl=en" target="CompList">ALL computer labs</a> and software w/version information <span class="style2"><em>(you will need to have an ObieID to see this info) </em></span><br> <strong> 
      </strong></td>
    </tr>
    <tr> 
      <td height="29" colspan="5" valign="top" class="results"> 
          <input type="hidden" name="searched" value="1">
           <input name="Submit" type="submit" class="buttons" value="Search">
		   <br/>
		   <span class="style2"><strong>Note:</strong> <em>You do not need to fill out every field.
          To display all classrooms hit the search button with no search options 
          selected.  </em></span><br></td>
    </tr>
    
  </form>
</table>

